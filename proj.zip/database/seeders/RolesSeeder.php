<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class RolesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Role::truncate();

        Role::create([
            'name' => 'user',
        ]);

        Role::create([
            'name' => 'reviewer',
        ]);

        Role::create([
            'name' => 'admin',
        ]);

        Role::create([
            'name' => 'editor',
        ]);
    }
}
