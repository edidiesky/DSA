<?php

namespace Database\Seeders;

use App\Models\Country;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CountriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */

    public function run()
    {
        $this->command->info('Truncating Countries table');

        Country::truncate();

        $this->command->info('Getting Countries Data');
        $countriesData = $this->parseCountries();
        $countriesData = array_merge(...array_values($countriesData));

        $this->command->info('Inserting into Countries table');
        if(Country::insert($countriesData)){

            $this->command->info('Countries Seeding Successfull');
        }

    }

    public function parseCountries(){

        $countriesJson = file_get_contents(__DIR__.'/countries.json');
        $data = json_decode( $countriesJson, true );

        return $data;
    }

}


