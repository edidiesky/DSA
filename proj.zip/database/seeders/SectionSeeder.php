<?php

namespace Database\Seeders;

use App\Models\Section;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SectionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Section::create([
            'name' => 'Preliminary Pages & General Engineering'
        ]);

        Section::create([
            'name' => 'Building, Civil & Geotechnical Engineering'
        ]);
        Section::create([
            'name' => 'Chemical, Industrial, Materials, Mechanical, Metallurgical, Petroleum & Production Engineering'
        ]);
        Section::create([
            'name' => 'Computer, Telecommunications, Software, Electrical & Electronics Engineering'
        ]);
        Section::create([
            'name' => 'Agricultural, Bioresources, Biomedical, Food, Environmental & Water Resources Engineering'
        ]);
        Section::create([
            'name' => 'Research papers of General Interest'
        ]);

        Section::create([
            'name' => 'Technical Notes/Short Communications/Letters to the Editor'
        ]);

    }
}
