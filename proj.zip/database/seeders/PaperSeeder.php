<?php

namespace Database\Seeders;

use PDO;
use App\Models\Paper;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class PaperSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        if (DB::connection()->getPDO()->getAttribute(PDO::ATTR_DRIVER_NAME) != 'sqlite') {

            // disable foreign key checks
            DB::statement('SET FOREIGN_KEY_CHECKS=0;');
            Paper::truncate();
            DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        }

        Paper::factory()->count(50)->create();
    }
}
