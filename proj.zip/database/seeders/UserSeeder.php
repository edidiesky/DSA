<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'first_name' => 'Test',
            'last_name' => 'User',
            'given_name' => 'User',
            'role_id' => 3,
            'email' => 'admin@gmail.com',
            "affiliation"   => 'uniuyo',
            'password' => \Hash::make('pa33word**'),
            'country'   => 1
        ]);
    }
}
