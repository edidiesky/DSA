<?php

namespace Database\Seeders;

use App\Models\PaperStatus;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PaperStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        PaperStatus::truncate();


        PaperStatus::insert([
            [
                'name'  => 'draft',
                'created_at'    => now(),
            ],
            [
                'name'  => 'submitted',
                'created_at'    => now(),

            ],
            [
                'name'  => 'under_review',
                'created_at'    => now(),

            ],
            [
                'name'  => 'approved',
                'created_at'    => now(),

            ],
            [
                'name'  => 'rejected',
                'created_at'    => now(),
            ],
            [
                'name'  => 'published',
                'created_at'    => now(),

            ],
        ]);
    }
}
