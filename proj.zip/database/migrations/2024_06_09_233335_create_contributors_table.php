<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('contributors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('paper_id')
                ->references('id')
                ->on('papers')
                ->onDelete('cascade');
            $table->string('affiliation')->nullable();
            $table->text('bio')->nullable();
            $table->string('country')->nullable();
            $table->string('email')->nullable();
            $table->string('family_name')->nullable();
            $table->string('given_name')->nullable();
            $table->boolean("is_primary_contact");
            $table->boolean('include_contributor');
            $table->string('orc_id')->nullable();
            $table->string('public_name')->nullable();
            $table->string('role_id')->nullable();
            $table->string('url')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('contributors');
    }
};
