<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('file_assets', function (Blueprint $table) {
            if (!Schema::hasColumn('file_assets', 'path')) {
                $table->string('path');
            }
            if (!Schema::hasColumn('file_assets', 'name')) {
                $table->string('name');
            }
            if (!Schema::hasColumn('file_assets', 'type')) {
                $table->string('type');
            }
        
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('file_assets');
    }
};
