<?php

namespace App\Http\Requests\Api;

use Illuminate\Foundation\Http\FormRequest;

class ArticleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title' => 'string|required',
            'abstract' => 'string|required',
            'authors' => 'array|required',
            'authors.*' => 'string',
            'section_id' => 'numeric|required|exists:sections,id',
            'document' => 'file|required|mimes:pdf,doc,docx,jpg,png|max:5120' // 5mb
            // 'reference' =>'string|required',
        ];
    }

    // public function messages()
    // {
    //     return [
    //         'document.max' => ':attribute maximum file size of :max KB exceeded'
    //     ];
    // }
}
