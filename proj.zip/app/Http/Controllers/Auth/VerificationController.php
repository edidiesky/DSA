<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class VerificationController extends Controller
{

    public function verify(Request $request, $id)
    {
        if (!$request->hasValidSignature()) {
            return response()->json(["msg" => "Invalid/Expired url provided."], 401);
        }

        $user = User::findOrFail($id);

        if($user){
            if (!$user->hasVerifiedEmail()) {
                $user->markEmailAsVerified();
            }
            
            $role = optional($user->role)->name;

            return redirect()->away("https://journal-fe-seven.vercel.app/journal?role=$role");
        }
    }

    public function resend(Request $request)
    {
        $user = auth()->user();


        if ($user->hasVerifiedEmail()) {
            return response()->json(["msg" => "Email already verified."], 400);
        }

        $user->sendEmailVerificationNotification();

        return response()->json(["msg" => "Email verification link has been sent on your email"]);
    }
}
