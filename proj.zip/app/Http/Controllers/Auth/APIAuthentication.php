<?php

namespace App\Http\Controllers\Auth;

use App\Events\LoginEvent;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;
use App\Models\User;
use App\Models\Role;
use Illuminate\Auth\Events\Registered;

class APIAuthentication extends Controller
{


    public function googleRedirect()
    {
        return response()->json([
            'url' => Socialite::driver('google')
                ->stateless()
                ->redirect()
                ->getTargetUrl(),
        ]);
    }


    public function loginWithGoogle(Request $request)
    {

        $request->validate([
            'email' => 'required|string|email|max:255',
            'google_id' => 'required|string'
        ]);

        $user = User::where('email', $request['email'])->first();

        if ($user) {
            if ($request->google_id == $user->google_id) {
                $token = $user->createToken('token')->accessToken;
                $response = ['user' => $user, 'token' => $token, 'role' => $user?->role?->name];
                return jsonResponse('success', $response);
            } else {
                $response = 'invalid user credentials';
                return jsonResponse('error', $response, 422);
            }
        } else {
            $response = 'User does not exist';
            return jsonResponse('error', $response, 422);
        }
    }


    public function googleCallback()
    {
        try {
            $google_user = Socialite::driver('google')->stateless()->user();

            $user = User::where('email', $google_user->email)->first();

            if (!$user) {
                [$firstname, $lastname] = explode(" ", $google_user->getName());
                // return $google_user->getName();
                $user = User::create([
                    'first_name' => $firstname,
                    'last_name' => $lastname,
                    'given_name' => $google_user->user['given_name'],
                    'affiliation' => 'None',
                    'country' => 'Nil',
                    'email' => $google_user->getEmail(),
                    'google_id' => $google_user->getId(),
                ]);
            }

            $token = $user->createToken('token')->accessToken;
            $response = ['user' => $user, 'token' => $token];
            return jsonResponse('success', $response);
        } catch (\Throwable $e) {
            return jsonResponse(status: 'error', data: $e->getMessage());
        }
    }



    public function registerWithGoogle(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'avatar' => 'string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'google_id' => 'required|string|unique:users',
        ]);



        $request['remember_token'] = Str::random(10);

        // create the user with the credentials
        $user = User::create([...$request->all(), 'role_id' => 1]);

        // get the user access token
        $token = $user->createToken('token')->accessToken;
        $response = ['token' => $token, 'user' => $user->toArray(), 'role' => $user?->role?->name];

        return jsonResponse(status: 'success', data: $response);
    }


    public function register(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'family_name' => 'required|string|max:255',
            'affiliation' => 'required|string|max:255',
            'country' => 'required|string|max:255',
            'avatar' => 'string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'google_id' => 'sometimes|string|unique:users',
            'password' => 'required|string|confirmed',
        ]);

        // hash the password and create remember token
        $request['password'] = Hash::make($request['password']);
        $request['remember_token'] = Str::random(10);

        // create the user with the credentials
        $user = User::create([...$request->all(), 'role_id' => Role::AUTHOR]);

        // get the user access token
        $token = $user->createToken('token')->accessToken;
        $response = ['token' => $token, 'user' => $user->toArray(), 'role' => $user?->role?->name];

        $user->sendEmailVerificationNotification();

        return jsonResponse(status: 'success', data: $response);
    }

    public function login(Request $request)
    {

        $validator = $request->validate([
            'email' => 'required|string|email|max:255',
            'password' => 'required|string'
        ]);

        $user = User::where('email', $request['email'])->first();

        if ($user) {
            if (Hash::check($request->password, $user->password)) {
                $token = $user->createToken('token')->accessToken;
                $response = ['user' => $user->toArray(), 'token' => $token, 'role' => $user?->role?->name];

                LoginEvent::dispatch($user, $request->ip());

                return jsonResponse('success', $response);
            } else {
                $response = 'Password mismatch';
                return jsonResponse('error', $response, 422);
            }
        } else {
            $response = 'User does not exist';
            return jsonResponse('error', $response, 422);
        }
    }



    public function logout(Request $request)
    {
        $token = $request->user()->token();
        $token->revoke();
        $response = 'You have been logged out';
        return jsonResponse('error', $response, 422);
    }
}
