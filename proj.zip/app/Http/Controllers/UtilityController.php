<?php

namespace App\Http\Controllers;

use App\Models\Country;
use Illuminate\Http\Request;

class UtilityController extends Controller
{
    public function getCountries()
    {
        $countries  = Country::all();

        return response()->json([
            'status'    => 'success',
            'data'      => $countries
        ]);
    }
}
