<?php

namespace App\Http\Controllers;

use App\Models\FileAsset;
use Illuminate\Http\Request;

class FileAssetsController extends Controller
{

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'file' => 'file|required|max:'.(10 * 1024),
            'type' => 'string|required',
            'paper_id' => 'numeric|required|exists:papers,id',
        ]);

        $file = $request->file;

        $filename = $file->getClientOriginalName();

        $path = $file->store('paper_files','public');


        if($path){
            
            $asset = FileAsset::create([
                'path' => $path,
                'name' => $filename,
                'type' => $request->type,
                'paper_id' => $request->paper_id,
            ]);
        
            return jsonResponse('success',$asset);
        }

        return jsonResponse('error',"Failed to upload file");
    }

    /**
     * Display the specified resource.
     */
    public function show(FileAsset $fileAsset)
    {

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, FileAsset $asset)
    {
        $request->validate([
            'file' => 'file|sometimes|max:'.(10 * 1024),
            'type' => 'string|sometimes',
            'paper_id' => 'numeric|sometimes|exists:papers,id',
        ]);
    
        if($request->type){
            $asset->type = $request->type;
        }

        $new_file = $request->file;

        if($asset->path && $new_file){
            \Storage::disk('public')->delete($asset->path);
            $filename = $request->file->getClientOriginalName();
            $path = $new_file->store('paper_files','public');
            $asset->path = $path;
            $asset->name = $filename;
        }


        if($request->paper_id){
            $asset->paper_id = $request->paper_id;
        }

        $asset->save();

        return response()->json([
            'status' => 'success',
            'message' => "Updated file type successfuly"
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(FileAsset $file)
    {
        if($file->path){
            \Storage::disk('public')->delete($file->path);
        }
        $file->delete();

        return response()->json([
            'status' => 'success',
            'message' => "Deleted file successfuly"
        ]);
    }
}
