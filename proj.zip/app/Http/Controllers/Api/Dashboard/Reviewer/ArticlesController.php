<?php

namespace App\Http\Controllers\Api\Dashboard\Reviewer;

use App\Http\Resources\AdminArticlesResource;
use App\Models\Comment;
use App\Models\Paper;
use App\Models\Role;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\PaperStatus;
use Illuminate\Support\Carbon;


class ArticlesController extends Controller
{

    private function checkPermissions($paper, $reviewer)
    {
        if ($reviewer->id != Role::REVIEWER) {
            return jsonResponse('error', 'This user is not a reviewer');
        }

        if ($reviewer->id != $paper->reviewer_id) {
            return jsonResponse('error', 'This reviewer was not assigned to this paper');
        }
    }


    public function reviewerAnalytics(): JsonResponse
    {
        $user  = auth()->user();

        $allArticles = Paper::where('reviewer_id',$user->id)->get();

        $data["articles"] = [
            'value'   =>  $allArticles->count(),
            'percentage_increase'   => 0,
        ];

        $data["approved_articles"] = [
            "value" =>   $allArticles->where('paper_status_id', PaperStatus::APPROVED)->count(),
            "percentage_increase"   => 0
        ];


        $data["rejected_articles"] =   [
            'value' => $allArticles->where('paper_status_id', PaperStatus::REJECTED)->count(),
            'percentage_increase'   => 0
        ];


        return jsonResponse('success', $data);
    }


    public function index(Request $request)
    {
        $validated = $request->validate([
            'start' => 'required|numeric',
            'length' => 'required|numeric',
            'query' => 'sometimes|string',
            'start_date' => 'sometimes|string',
            'end_date' => 'sometimes|string',
        ]);

        $start = $validated['start'];
        $length = $validated['length'];
        $query = isset($validated['query']) ? $validated['query'] : null;
        $startDate = isset($validated['start_date']) ? Carbon::parse($validated['start_date']) : null;
        $endDate = isset($validated['end_date']) ? Carbon::parse($validated['end_date']) : null;


        $paperQuery = Paper::whereNot('paper_status_id', PaperStatus::DRAFT)->orderBy('created_at', 'desc');
        $paperQuery->where('reviewer_id', $request->user()->id);

        if ($query) {

            $paperQuery->where(function ($q) use ($query) {
                $q->where('title', 'like', "%{$query}%")
                    ->orWhere('abstract', 'like', "%{$query}%")
                    ->orWhere('slug', 'like', "%{$query}%");
            });
        }

        if ($startDate && $endDate) {
            $paperQuery->whereBetween('created_at', [$startDate, $endDate]);
        } else if ($startDate) {
            $paperQuery->where('created_at', '>=', $startDate);
        } else if ($endDate) {
            $paperQuery->where('created_at', '<=', $endDate);
        }

        $totalCount = $paperQuery->count();
        $papers = $paperQuery->skip($start)->take($length)->get();

        return jsonResponse([
            "recordsFiltered" => $papers->count(),
            "totalRecords" => $totalCount,
            "data" => AdminArticlesResource::collection($papers->values()),
        ]);
    }



    public function createReviewerComment(Request $request, Paper $paper)
    {

        $reviewer = auth()->user();

        // $this->checkPermissions($paper, $reviewer);

        $request->validate([
            'content' => 'string|required|max:2000'
        ]);


        Comment::create([
            'user_id' => $reviewer->id,
            'paper_id' => $paper->id,
            'content' => $request->content
        ]);

        return jsonResponse('success', 'created comment for article');
    }


    public function getComments(Request $request, Paper $paper)
    {
        $reviewer = $request->user();
        $this->checkPermissions($paper, $reviewer);
        $comments = $paper->comments;
        return jsonResponse('success', $comments);
    }


    public function changePaperStatus(Request $request, Paper $paper)
    {
        $request->validate([
            'status_id' => 'required|numeric|exists:paper_status,id',
        ]);

        $paper->paper_status_id = $request->status_id;
        if($request->status_id == PaperStatus::PUBLISHED){
            $paper->published_on = now();
        }else{
            $$paper->published_on = null;
        }

        $paper->save();

        return response()->json([
            'status' => 'success',
            'message' => 'article status changed'
        ]);
    }

}
