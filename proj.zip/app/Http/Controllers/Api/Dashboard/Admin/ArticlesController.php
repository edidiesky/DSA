<?php

namespace App\Http\Controllers\Api\Dashboard\Admin;

use App\Models\Paper;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\AdminArticlesResource;
use App\Models\PaperStatus;
use App\Models\Role;
use App\Models\User;
use App\Notifications\PaperAssignedNotification;
use App\Notifications\PaperUnderReviewNotification;
use Illuminate\Support\Carbon;

class ArticlesController extends Controller
{

    public function index(Request $request)
    {
        $validated = $request->validate([
            'start' => 'required|numeric',
            'length' => 'required|numeric',
            'query' => 'sometimes|string',
            'start_date' => 'sometimes|string',
            'end_date' => 'sometimes|string',
        ]);

        $start = $validated['start'];
        $length = $validated['length'];
        $query = isset($validated['query']) ? $validated['query'] : null;
        $startDate = isset($validated['start_date']) ? Carbon::parse($validated['start_date']) : null;
        $endDate = isset($validated['end_date']) ? Carbon::parse($validated['end_date']) : null;


        $paperQuery = Paper::whereNot('paper_status_id', PaperStatus::DRAFT)->orderBy('created_at', 'desc');

        if ($query) {

            $paperQuery->where(function ($q) use ($query) {
                $q->where('title', 'like', "%{$query}%")
                    ->orWhere('abstract', 'like', "%{$query}%")
                    ->orWhere('slug', 'like', "%{$query}%");
            });
        }

        if ($startDate && $endDate) {
            $paperQuery->whereBetween('created_at', [$startDate, $endDate]);
        } else if ($startDate) {
            $paperQuery->where('created_at', '>=', $startDate);
        } else if ($endDate) {
            $paperQuery->where('created_at', '<=', $endDate);
        }

        $totalRecords = $paperQuery->get()->count();
        $papers = $paperQuery->skip($start)->take($length)->get();

        return jsonResponse([
            "recordsFiltered" => $papers->count(),
            "totalRecords" => $totalRecords,
            "data" => AdminArticlesResource::collection($papers->values()),
        ]);
    }

    public function draph()
    {
        
    }



    public function changePaperStatus(Request $request, Paper $paper)
    {
        $request->validate([
            'status_id' => 'required|numeric|exists:paper_status,id',
        ]);

        $paper->paper_status_id = $request->status_id;
        if($request->status_id == PaperStatus::PUBLISHED){
            $paper->published_on = now();
        }else{
            $paper->published_on = null;
        }

        $paper->save();

        return response()->json([
            'status' => 'success',
            'message' => 'article status changed'
        ]);
    }



    public function assignPaper(Request $request, Paper $paper)
    {
        $request->validate([
            'reviewer' => 'required|exists:users,id'
        ]);

        if ($paper->reviewer_id) {
            return response()->json([
                'status' => 'error',
                'message' => "Paper has already been assigned to a reviewer"
            ], 400);
        }


        $acceptedRoles = [Role::ADMIN, Role::REVIEWER];


        $reviewer = User::find($request->reviewer);

        if (!in_array($reviewer?->role_id, $acceptedRoles)) {
            return response()->json([
                'status' => 'error',
                'message' => "Paper Review cannot be assigned to this user"
            ], 400);
        }


        $paper->reviewer_id = $reviewer->id;
        $paper->paper_status_id = PaperStatus::UNDER_REVIEW;
        $paper->save();


        // notify the user
        $paper?->user->notify(new PaperUnderReviewNotification($paper));

        // notify the reviewer
        $reviewer->notify(new PaperAssignedNotification($paper));



        return response()->json([
            'status' => 'success',
            'message' => "Paper has been assigned to $reviewer->first_name $reviewer->last_name successfully"
        ]);
    }

    public function reAssignPaper(Request $request, Paper $paper)
    {
        $request->validate([
            'reviewer' => 'required|exists:users,id'
        ]);

        if (!$paper->reviewer_id) {
            return response()->json([
                'status' => 'error',
                'message' => "Paper has not been assigned to a reviewer"
            ], 400);
        }


        $acceptedRoles = [Role::ADMIN, Role::REVIEWER];

        $reviewer = User::find($request->reviewer);

        if (!in_array($reviewer?->role_id, $acceptedRoles)) {
            return response()->json([
                'status' => 'error',
                'message' => "Paper Review cannot be assigned to this user"
            ], 400);
        }


        $paper->reviewer_id = $reviewer->id;
        $paper->paper_status_id = PaperStatus::UNDER_REVIEW;
        $paper->save();


        // notify the user
        $paper?->user->notify(new PaperUnderReviewNotification($paper));

        // notify the reviewer
        $reviewer->notify(new PaperAssignedNotification($paper));



        return response()->json([
            'status' => 'success',
            'message' => "Paper has been assigned to $reviewer->first_name $reviewer->last_name successfully"
        ]);
    }
}
