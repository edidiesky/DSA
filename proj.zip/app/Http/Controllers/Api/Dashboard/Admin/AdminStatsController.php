<?php

namespace App\Http\Controllers\Api\Dashboard\Admin;

use App\Models\Role;
use App\Models\User;
use App\Models\Paper;
use App\Models\PaperStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use App\Http\Controllers\Controller;


class AdminStatsController extends Controller
{
    //


    public function getCollectionStat(Collection $collection)
    {
        $currentDate = Carbon::now();

        // Calculate dates for this month and last month
        $thisMonthStart = $currentDate->copy()->startOfMonth();
        $thisMonthEnd = $currentDate->copy()->endOfMonth();
        $lastMonthStart = $thisMonthStart->copy()->subMonth();
        $lastMonthEnd = $lastMonthStart->copy()->endOfMonth();



        // Count users for this month and last month
        $thisMonthCount = $collection->whereBetween('created_at', [$thisMonthStart, $thisMonthEnd])->count();
        $lastMonthCount = $collection->whereBetween('created_at', [$lastMonthStart, $lastMonthEnd])->count();

        $increase = 0;
        if ($lastMonthCount > 0) {
            $increase = (($thisMonthCount - $lastMonthCount) / $lastMonthCount) * 100;
        }
        $stat = new \StdClass;
        $stat->count = $collection->count();
        $stat->percentage = number_format($increase, 2) . '%';
        $stat->thisMonthCount = $thisMonthCount;
        $stat->lastMonthCount = $lastMonthCount;

        return $stat;
    }


    public function adminStats(Request $request)
    {

        // Format and return the data

        $articlesStats = $this->getCollectionStat(Paper::whereNot('paper_status_id', PaperStatus::DRAFT)->get());

        $admin = Role::where('name', 'admin')->first();
        if (!$admin) {
            return jsonResponse(status: 'error', data: ['message' => 'admin role not found on database']);
        }

        $usersStats = $this->getCollectionStat(User::where('role_id', '!=', $admin->id)->get());

        $dummyStat = new \StdClass;
        $dummyStat->count = 0;
        $dummyStat->percentage = number_format(0, 2) . '%';
        $dummyStat->thisMonthCount = 0;
        $dummyStat->lastMonthCount = 0;

        $response = [
            'articles' => $articlesStats,
            'users' => $usersStats,
            'revenue' =>  $dummyStat,
            'review' =>  $dummyStat,
        ];

        return jsonResponse("success", $response);
    }
}
