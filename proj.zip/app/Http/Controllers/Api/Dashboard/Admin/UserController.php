<?php

namespace App\Http\Controllers\Api\Dashboard\Admin;

use App\Mail\InviteMail;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;

class UserController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        if ($request->has("search_query")) {

            $users = User::where(function ($query) use ($request) {
                $query->where('first_name', 'like', "%{$request->search_query}%")
                    ->orWhere('last_name', 'like', "%{$request->search_query}%")
                    ->orWhere('email', 'like', "%{$request->search_query}%");
            })->limit(20)->get();
        } else {
            $users = User::limit(20)->get();
        }


        return response()->json(UserResource::collection($users));
    }

    public function getReviewers(Request $request): JsonResponse
    {
        if ($request->has("search_query")) {

            $users = User::where('role_id', Role::REVIEWER)->where(function ($query) use ($request) {
                $query->where('first_name', 'like', "%{$request->search_query}%")
                    ->orWhere('last_name', 'like', "%{$request->search_query}%")
                    ->orWhere('email', 'like', "%{$request->search_query}%");
            })->limit(20)->get();
        } else {
            $users = User::where('role_id', Role::REVIEWER)->limit(5)->get();
        }


        return response()->json(UserResource::collection($users));
    }


    public function search_users(Request $request): JsonResponse
    {
        $users = User::limit(20)->get();

        return response()->json(UserResource::collection($users));
    }


    public function destroy(User $user): JsonResponse
    {
        if ($user->delete()) {
            return response()->json([
                'status' => 'success',
                'message' => 'Successfully Deleted User'
            ]);
        }

        return response()->json([
            'status' => 'error',
            'message' => 'An Unexpected Error occured Please try again later'
        ], 500);
    }


    public function updateUserRole(Request $request)
    {
        $request->validate(
            [
                'user_id' => 'numeric|required|exists:users,id',
                'role_id' => 'numeric|required|exists:roles,id',
            ],
            [
                'user_id' => 'this user does not exist',
                'role_id' => 'this role does not exist'
            ]
        );

        $user = User::find($request->user_id);
        $user->role_id = $request->role_id;

        $user->save();

        return response()->json([
            'status' => 'success',
            "message" => "Updated user role"
        ]);
    }


    public function inviteUser(Request $request)
    {
        $request->validate([
            'email' => 'string|required',
            'role_id' => 'numeric|required'
        ]);


        if (User::withTrashed()->where('email', $request->email)->exists()){
            return jsonResponse('error', "User with email already exist");
        }


        $password = substr(sha1(time()), 0, 12);

        $user = User::create([
            'email' => $request->email,
            'password' => $password,
            'email_verified_at' => now()
        ]);

        \Mail::to($request->email)->send(new InviteMail(user: $user, admin: auth()->user(), password: $password));

        return response()->json([
            'status' => 'success',
            'message' => 'Successfully sent invitation'
        ]);

    }
}
