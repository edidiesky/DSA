<?php

namespace App\Http\Controllers\Api\Dashboard\Author;


use App\Http\Controllers\Controller;
use App\Models\PaperStatus;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(): JsonResponse
    {
        $user  = auth()->user();
        $allArticles = $user->papers;

        $data["articles"] = [
            'value'   =>  $allArticles->count(),
            'percentage_increase'    => 20,

        ];

        $data["approved_articles"] = [
            "value" =>   $allArticles->where('paper_status_id', PaperStatus::APPROVED)->count(),
            "percentage_increase"   => -20
        ];


        $data["rejected_articles"] =   [
            'value' => $allArticles->where('paper_status_id', PaperStatus::REJECTED)->count(),
            'percentage_increase'   => 0
        ];

        $data["total_reads"] =   [
            'value' => array_sum($allArticles->map(fn ($article) => $article->downloads->count())->toArray()),
            'percentage_increase'   => 0
        ];

        return jsonResponse('success', $data);
    }
}
