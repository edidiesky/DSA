<?php

namespace App\Http\Controllers\Api\Dashboard\Author;

use App\Models\Contributor;
use App\Models\PaperDraft;
use App\Models\Role;
use Carbon\Carbon;
use App\Models\Paper;
use App\Models\Comment;
use App\Models\PaperStatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\Api\ArticleRequest;
use App\Http\Resources\AuthorPaperResource;

class ArticlesController extends Controller
{
    public function index(Request $request)
    {
        $validated = $request->validate([
            'start' => 'required|numeric',
            'length' => 'required|numeric',
            'query' => 'sometimes|string',
            'start_date' => 'sometimes|string',
            'end_date' => 'sometimes|string',
        ]);
        $user = $request->user();

        $query = isset($validated['query']) ? $validated['query'] : null;
        // $startDate = isset($validated['start_date']) ? Carbon::parse($validated['start_date']) : null;
        // $endDate = isset($validated['end_date']) ? Carbon::parse($validated['end_date']) : null;


        $allArticles = $user->papers()->orderBy('created_at', 'desc');

        if ($query) {

            $allArticles->where(function ($q) use ($query) {
                $q->where('title', 'like', "%{$query}%")
                    ->orWhere('abstract', 'like', "%{$query}%")
                    ->orWhere('slug', 'like', "%{$query}%");
            });
        }

        $totalRecords = $allArticles->get()->count();
        $papers = $allArticles->skip($request->start)->take($request->length)->get();

        return jsonResponse([
            "recordsFiltered" => $papers->count(),
            "totalRecords" => $totalRecords,
            "data" => AuthorPaperResource::collection($papers->values()),
        ]);
    }


    public function update(Request $request, Paper $paper)
    {

        $request->validate([
            'title' => 'string|sometimes',
            'abstract' => 'string|sometimes',
            'authors' => 'array|sometimes',
            'authors.*' => 'string',
            'document' => 'sometimes|mimes:pdf,doc,docx,jpg,png|max:5120',
            'reference' => 'array|sometimes',
            'reference.*' => 'string',
            'keywords' => 'array|sometimes',
            'keywords.*' => 'string',

            'contributors.*.affiliation' => 'string|sometimes|nullable',
            'contributors.*.bio' => 'string|sometimes|nullable',
            'contributors.*.country' => 'string|sometimes|nullable',
            'contributors.*.email' => 'email|sometimes|nullable',
            'contributors.*.family_name' => 'string|sometimes|nullable',
            'contributors.*.given_name' => 'string|sometimes|nullable',
            'contributors.*.include_contributor' => 'boolean|sometimes|nullable',
            "contributors.*.is_primary_contact" => 'boolean|sometimes|nullable',
            'contributors.*.orc_id' => 'string|sometimes|nullable',
            'contributors.*.role' => 'string|sometimes|nullable|in:author,translator',
            'contributors.*.public_name' => 'string|sometimes|nullable',
            'contributors.*.url' => 'string|sometimes|nullable',


            'comment' => 'string|sometimes',
            'types' => 'string|sometimes',
            'disciplines' => 'array|sometimes',
            'disciplines.*' => 'string',
            'supporting_agencies' => 'array|sometimes',
            'supporting_agencies.*' => 'string',
        ]);


        if ($request->contributors) {
            // first clear the contributors for this paper
            Contributor::where('paper_id', $paper->id)->delete();

            foreach ($request->contributors as $contributor) {
                $contributor['paper_id'] = $paper->id;
                Contributor::create($contributor);
            }
        }



        if ($request->document) {
            $file_path = explode('storage/', $paper->file_path)[1];
            $path = $request->document->store('public/documents');
            Storage::disk('public')->delete($file_path);
            $paper->file_path = $path;
        }

        $paper->update($request->except('document', '_method'));
        return jsonResponse(status: 'success', data: $paper->load('contributors'));
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(ArticleRequest $request)
    {
        // $request->validate([
        //     'title' => 'string|sometimes',
        //     'abstract' => 'string|sometimes',
        //     'authors' => 'array|sometimes',
        //     'authors.*' => 'string',
        //     'document' => 'sometimes|mimes:pdf,doc,docx,jpg,png|max:5120'
        // ]);
        // $data = $request->all();
        // $data['user_id'] = $request->user()->id;
        // $data['paper_status_id'] = PaperStatus::SUBMITTED;

        // $path = $request->document->store('public/documents');

        // $data['file_path'] = $path;

        // if ($path) {
        //     $paper = Paper::create($data);
        //     return jsonResponse(status: 'success', data: new AuthorPaperResource($paper));
        // }

        // return jsonResponse(status: 'error', data: ['message' => 'failed to upload document']);
    }

    public function createDraft(Request $request)
    {
        $request->validate([
            'title' => 'string|sometimes',
            'section_id' => 'numeric|exists:sections,id'
        ]);

        $user = $request->user();

        $paper = Paper::create([
            'user_id' => $user->id,
            'title' => $request->title,
            'section_id' => $request->section_id,
            'paper_status_id' => PaperStatus::DRAFT,
        ]);

        $draft = PaperDraft::create([
            'user_id' => $user->id,
            'paper_id' => $paper->id,
        ]);

        return jsonResponse(
            status: 'success',
            data: $draft
        );
    }


    public function saveDraftStage(Request $request, PaperDraft $draft)
    {
        $stage = $draft->stage + 1;
        if ($request->stage) {
            $stage = $request->stage;
        }
        switch ($stage) {
            case 2:
                $request->validate([
                    // 'document' => 'sometimes|mimes:pdf,doc,docx,jpg,png|max:5120',
                    'abstract' => 'string|required',
                    'reference' => 'array|required',
                    'title' => 'string|required',
                    'reference.*' => 'string',
                    'keywords' => 'array|required',
                    'keywords.*' => 'string',
                ]);

                $data = $request->only('abstract', 'reference', 'title', 'keywords');

                $draft->paper->update($data);

                $draft->stage = 2;
                $draft->save();

                return jsonResponse(status: 'success', data: $draft->load('paper'));


            case 3:
                $request->validate([
                    'document' => 'required|mimes:pdf,doc,docx,jpg,png|max:5120',
                ]);


                if ($draft->paper->file_path) {
                    $file_dir = explode('storage/', $draft->paper->file_path)[1];
                    Storage::disk('public')->delete($file_dir);
                }
                $path = $request->document->store('public/documents');

                if ($path) {
                    $draft->paper()->update([
                        'file_path' => $path,
                    ]);
                    $draft->stage = 3;
                    $draft->save();
                    // return updated draft and paper relationship
                    return jsonResponse(status: 'success', data: $draft->load('paper'));
                }

                return jsonResponse(status: 'error', data: ['message' => 'failed to upload document']);


            case 4:
                $data = $request->validate([
                    'contributors.*.affiliation' => 'string|nullable',
                    'contributors.*.bio' => 'string|nullable|sometimes',
                    'contributors.*.country' => 'string|required',
                    'contributors.*.email' => 'email|required',
                    'contributors.*.family_name' => 'string|sometimes|nullable',
                    'contributors.*.given_name' => 'string|required',
                    'contributors.*.include_contributor' => 'boolean|nullable',
                    "contributors.*.is_primary_contact" => 'boolean|nullable',
                    'contributors.*.orcid_id' => 'string|sometimes|nullable',
                    'contributors.*.role' => 'string|nullable|in:author,translator',
                    'contributors.*.public_name' => 'string|nullable|sometimes',
                    'contributors.*.url' => 'string|nullable|sometimes',
                ]);

                // no need for the optinal sha, you never know
                Contributor::where('paper_id', optional($draft)->paper->id)->delete();

                $contributors = [];

                foreach ($request->contributors as $contributor) {
                    $contributor['paper_id'] = $draft->paper->id;
                    $con = Contributor::create($contributor);
                    $contributors[] = $con;
                }

                $draft->stage = 4;
                $draft->save();

                return jsonResponse(status: 'success', data: $draft->load('paper'));


            case 5:
                $request->validate([
                    'comment' => 'string|sometimes|nullable',
                    'types' => 'string|required',
                    'disciplines' => 'array|required',
                    'disciplines.*' => 'string|sometimes|nullable',
                    'supporting_agencies' => 'array|required|sometimes|nullable',
                    'supporting_agencies.*' => 'string',
                ]);

                $data = $request->only('abstract', 'disciplines', 'types', 'comment', 'supporting_agencies');

                // return $data;
                $draft->paper->update([
                    'for_editors' => $data
                ]);



                $draft->stage = 5;
                $draft->save();


                return jsonResponse(status: 'success', data: $draft->load('paper'));


            case 6:
                $draft->paper->update([
                    'paper_status_id' => PaperStatus::SUBMITTED
                ]);

                $paper = $draft->load('paper');

                $draft->delete();

                return jsonResponse(
                    status: 'success',
                    data: $paper
                );

            default:
                break;
        }

    }

    public function getDrafts(Request $request)
    {

        return jsonResponse(
            status: 'success',
            data: $request->user()->drafts()->get()
        );
    }

    public function createComment(Request $request, Paper $paper)
    {

        $user = auth()->user();

        $request->validate([
            'content' => 'string|required|max:2000'
        ]);

        Comment::create([
            'user_id' => $user->id,
            'paper_id' => $paper->id,
            'content' => $request->content
        ]);

        return jsonResponse('success', 'created comment for article');
    }


    public function getComments(Request $request, Paper $paper)
    {
        $comments = $paper->comments;
        return jsonResponse('success', $comments);
    }
}
