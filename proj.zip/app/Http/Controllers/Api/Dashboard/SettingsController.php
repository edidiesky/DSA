<?php

namespace App\Http\Controllers\Api\Dashboard;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;

class SettingsController extends Controller
{
    public function updatePassword(Request $request): JsonResponse
    {
        $user = $request->user();

        $request->validate(
            [
                'old_password'  => 'required',
                'password'  => 'required|min:8|confirmed',
            ]
        );

        if (!Hash::check($request->old_password, $user->password)) {
            return response()->json([
                'status'    => 'error',
                'message'   => 'Old Password Does not match'
            ], 400);
        }

        $user->password = $request->password;
        $user->save();

        return response()->json([
            'status'    => 'success',
            'message'   => 'Successfully Updated Password'
        ]);
    }


    public function updateAvatar(Request $request) {
        $user = auth()->user();

        $request->validate([
            'profile_image' => 'required|image|mimes:jpg,png,bmp|max:'. (10 * 1024),
        ]);

        $path = $request->profile_image->store('images','public');
        
        
        if($user->avatar){
            \Storage::disk('public')->delete($user->avatar);
        }

        $user->avatar = $path;
        $user->save();

        return response()->json([
            'status' => 'success',
            'data' => [
                'profile_image' => asset('storage/'.$path)
            ]
        ]);
    }

    public function updateAccount(Request $request): JsonResponse
    {
        $request->validate([
            'first_name'    => 'required|string|max:20',
            'last_name'    => 'required|string|max:20',
            'family_name' => 'required|string|max:20',
            'affiliation' => 'required|string|max:255',
            'country' => 'required|string',
            // 'email'    => 'required|email',
        ]);

        $user = $request->user();


        $user->first_name  = $request->first_name;
        $user->last_name  = $request->last_name;
        // $user->email = $request->email;
        $user->family_name = $request->family_name;
        $user->affiliation = $request->affiliation;
        $user->country = $request->country;

        $user->save();

        return response()->json([
            'status'    => 'success',
            'message'   => 'Successfully Updated Account Information'
        ]);
    }
}
