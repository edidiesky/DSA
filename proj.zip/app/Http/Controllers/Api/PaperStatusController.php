<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\PaperStatus;

class PaperStatusController extends Controller
{
    public function index()
    {
        $status = PaperStatus::all();
        return jsonResponse("success", $status);
    }
}
