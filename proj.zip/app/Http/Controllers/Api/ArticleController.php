<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\AuthorPaperResource;
use App\Http\Resources\PaperDetailsResource;
use App\Models\PaperDraft;
use App\Models\PaperStatus;
use App\Models\PaperViews;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;

use App\Models\Paper;
use App\Http\Requests\Api\ArticleRequest;
use App\Http\Resources\PaperResource;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Storage;

class ArticleController extends Controller
{

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $validated = $request->validate([
            'start' => 'required|numeric',
            'length' => 'required|numeric',
            'query' => 'sometimes|string',
            'start_date' => 'sometimes|string',
            'end_date' => 'sometimes|string',
        ]);

        $start = $validated['start'];
        $length = $validated['length'];
        $query = isset($validated['query']) ? $validated['query'] : null;
        $startDate = isset($validated['start_date']) ? Carbon::parse($validated['start_date']) : null;
        $endDate = isset($validated['end_date']) ? Carbon::parse($validated['end_date']) : null;


        $paperQuery = Paper::whereNotNull('published_on')->orderBy('created_at', 'desc');

        if ($query) {
            $paperQuery->where(function ($q) use ($query) {
                $q->where('title', 'like', "%{$query}%")
                    ->orWhere('abstract', 'like', "%{$query}%")
                    ->orWhere('slug', 'like', "%{$query}%");
            });
        }

        if ($startDate && $endDate) {
            $paperQuery->whereBetween('created_at', [$startDate, $endDate]);
        } else if ($startDate) {
            $paperQuery->where('created_at', '>=', $startDate);
        } else if ($endDate) {
            $paperQuery->where('created_at', '<=', $endDate);
        }
        $totalCount = $paperQuery->count();

        $papers = $paperQuery->skip($start)->take($length)->get();

        return jsonResponse([
            "recordsFiltered" => $papers->count(),
            "totalRecords" => $totalCount,
            "data" => $papers->values(),
        ]);
    }


    // search

    public function search(Request $request)
    {
        $request->validate([
            'query' => 'string|required',
        ]);

        $query = $request->get('query');

        $articles = Paper::search($query)->get();

        return jsonResponse(status: 'success', data: $articles);
    }


    /**
     * Display the specified resource.
     */
    public function show(Request $request, Paper $paper)
    {
        $draft = PaperDraft::where('paper_id', $paper->id)->first();

        $ip = $request->ip();

        if (
            !PaperViews::where('paper_id', $paper->id)
                ->where('ip_address', $ip)->exists()
        ) {
            PaperViews::create([
                'paper_id' => $paper->id,
                'ip_address' => $ip
            ]);
        }
        $paper->save();
        if ($draft) {
            $paper->draft = $draft;
        }

        return jsonResponse('success', new  PaperDetailsResource($paper));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(ArticleRequest $request, Paper $paper)
    {
        $paper->update($request->all());
        return jsonResponse(status: 'success', data: $paper);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Paper $paper)
    {
        $user = auth()->user();

        // make sure only the owner and an admin can delete the article;
        if ($user->role->name == 'admin' || $paper->user_id == $user->id) {
            if ($paper->file_path) {
                $path = explode('storage/', $paper->file_path)[1];
                Storage::disk('public')->delete($path);
            }

            $paper->delete();

            return jsonResponse('success', ['message' => 'deleted article']);
        } else {
            return jsonResponse('error', 'You do not have permission to delete this article');
        }
    }

    public function download(Request $request, Paper $paper)
    {



        $file  = $paper->files->firstWhere('type', 'article_text');
        if (!$file) {
            return abort(404);
        }
        $paper->downloads()->create([
            'ip_address' => $request->ip(),
        ]);

        return response()->download("storage/" . $file->path);
    }
}
