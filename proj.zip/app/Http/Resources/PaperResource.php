<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Resources\Json\JsonResource;

class PaperResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id'        => $this->id,
            'title'     => $this->title,
            'authors'   => $this->authors,
            'published_on'  => $this->published_on,
            'abstract' => $this->abstract,
            'file_path' => Storage::url($this->file_path),
            'slug' => $this->slug,
            'status_id' => $this?->status?->id,
            'status' => $this?->status?->name,
            'files' => $this?->files
        ];
    }
}
