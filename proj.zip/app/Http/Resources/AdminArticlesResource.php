<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Resources\Json\JsonResource;

class AdminArticlesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $author  = $this->user;
        $reviewer  = $this->reviewer;
        return [
            'id'    =>  $this->id,
            'slug'  => $this->slug,
            'title'  => $this->title,
            'author'    => "$author?->first_name $author?->last_name",
            'reviewer'    => $reviewer ? [
                'name'      => "$reviewer?->first_name $reviewer?->last_name",
                'email'     => $reviewer->email,
                'avatar'    =>  $reviewer->avatar ? Storage::url($this->avatar) : null
            ] : null,
            'date'  => $this->created_at->format('Y/m/d'),
            'status'    => $this?->status?->name,
            'status_id' => $this?->status?->id,
            'files' => $this->files
        ];
    }
}
