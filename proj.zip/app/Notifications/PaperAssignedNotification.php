<?php

namespace App\Notifications;

use App\Models\Paper;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class PaperAssignedNotification extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     */
    public function __construct(public Paper $paper)
    {
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail', 'database'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->greeting("Hello $notifiable->first_name $notifiable->last_name")
            ->line("A new Paper has been assigned to you for review title '{$this->paper->title}'")
            ->line('You can login to your dashboard to see the paper and review')
            ->action('Click on the link to access the paper', env('FE_URL') . "/reviewer/articles/{$this->paper->slug}");
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            'title' => 'Paper Review Assigned',
            "message"   => "A new Paper has been assigned to you for review title '{$this->paper->title}'",
            "paper_id"  => $this->paper->id,
        ];
    }
}
