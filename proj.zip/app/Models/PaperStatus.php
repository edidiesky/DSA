<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PaperStatus extends Model
{
    use HasFactory;
    protected $table = 'paper_status';
    const DRAFT = 1;
    const SUBMITTED = 2;
    const UNDER_REVIEW = 3;
    const APPROVED = 4;
    const REJECTED = 5;
    const PUBLISHED = 6;
}
