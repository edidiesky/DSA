<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PaperViews extends Model
{
    use HasFactory;
    protected $fillable = [
        'ip_address','paper_id'
    ];
}
