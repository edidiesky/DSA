<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Spatie\Sluggable\SlugOptions;
use Spatie\Sluggable\HasSlug;

class Paper extends Model
{
    use HasFactory, HasSlug;
    protected $fillable = [
        'slug',
        'title',
        'content',
        'abstract',
        'authors',
        'file_path',
        'reviewer_id',
        'reference',
        'keywords',
        'published_on',
        'transaction_id',
        'for_editors',
        'user_id',
        'section_id',
        'paper_status_id',
    ];

    protected $with = ['section', 'contributors', 'files'];
    protected $appends = ['views_count', 'download_count'];

    protected $hidden = [
        'views'
    ];
    protected $casts = [
        'authors' => 'array',
        'keywords' => 'array',
        'reference' => 'array',
        'for_editors' => 'object',
    ];

    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('title')
            ->saveSlugsTo('slug');
    }

    public function draft()
    {
        return $this->hasOne(PaperDraft::class);
    }

    public function toSearchableArray()
    {
        return [
            'title' => $this->title,
            'abstract' => $this->abstract,
        ];
    }

    public function contributors()
    {
        return $this->hasMany(Contributor::class);
    }

    public function getAuthorsAttribute($value)
    {
        return json_decode($value);
    }

    public function getFilePathAttribute($value)
    {
        if ($value) {
            return asset(Storage::url($value));
        }
        return $value;
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function status()
    {
        return $this->belongsTo(PaperStatus::class, 'paper_status_id');
    }

    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function section()
    {
        return $this->belongsTo(Section::class);
    }

    public function comments(): HasMany
    {
        return $this->hasMany(Comment::class)->with('user');
    }

    public function downloads(): HasMany
    {
        return $this->hasMany(PaperDownloads::class);
    }

    public function getViewsCountAttribute()
    {
        return $this->views->count();
    }

    public function views(): HasMany
    {
        return $this->hasMany(PaperViews::class);
    }

    public function files(): HasMany
    {
        return $this->hasMany(FileAsset::class, 'paper_id');
    }

    public function getDownloadCountAttribute()
    {
        return $this->downloads->count();
    }
}
