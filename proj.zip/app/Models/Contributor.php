<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Contributor extends Model
{
    use HasFactory;

    protected $fillable = [
        'paper_id',
        'affiliation',
        'bio',
        'country',
        'email',
        'family_name',
        'given_name',
        'include_contributor',
        'orcid_id',
        'public_name',
        'role',
        "is_primary_contact",
        'url',
    ];

    public function paper(){
        return $this->belongsTo(Paper::class);
    }

    protected $casts = [
        'is_primary_contact' => 'boolean',
        'include_contributor' => 'boolean',
    ];
}
