<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FileAsset extends Model
{
    use HasFactory;
    protected $fillable = [
        "path",'type','name','paper_id'
    ];

    protected $appends = [
        'url'
    ];


    public function paper(){
        return $this->belongsTo(Paper::class);
    }
    public function getUrlAttribute(){
        return asset('storage/'.$this->path);
    }

}
