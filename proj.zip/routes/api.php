<?php

use App\Http\Controllers\Api\Dashboard\Admin\AdminStatsController;
use App\Http\Controllers\Auth\VerificationController;
use App\Http\Controllers\FileAssetsController;
use App\Http\Controllers\InviteController;
use App\Http\Controllers\SectionsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Api\ArticleController;
use App\Http\Controllers\Api\Dashboard\Admin\ArticlesController as AdminArticlesController;
use App\Http\Controllers\Api\Dashboard\Reviewer\ArticlesController as ReviewerArticlesController;
use App\Http\Controllers\Api\Dashboard\Admin\UserController;
use App\Http\Controllers\Api\Dashboard\Author\ArticlesController;
use App\Http\Controllers\Auth\APIAuthentication;
use App\Http\Controllers\Api\RoleController;
use App\Http\Controllers\Api\Dashboard\Author\DashboardController;
use App\Http\Controllers\Api\Dashboard\SettingsController;
use App\Http\Controllers\UtilityController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/



Route::group(['prefix' => 'v1'], function () {
    Route::get('email/verify/{id}', [VerificationController::class, 'verify'])->name('verification.verify');

    Route::get('email/resend', [VerificationController::class, 'resend'])
        ->name('verification.resend')
        ->middleware('auth:api');


    Route::get('auth/google/redirect', [APIAuthentication::class, 'googleRedirect'])->name('google-auth');
    Route::get('auth/callback', [APIAuthentication::class, 'googleCallback']);


    Route::middleware(['auth:api'])->group(function () {
        Route::get('/', function () {
            return ['message' => 'Welcome to University of Uyo Journal API: v1'];
        });

        Route::get('/user', function (Request $request) {
            return jsonResponse("success", auth()->user());
        });

        Route::post('/logout', [APIAuthentication::class, 'logout'])->name('logout.api');




        Route::prefix('dashboard')->group(function () {

            Route::prefix('settings')->controller(SettingsController::class)->group(function () {
                Route::post('update-password', 'updatePassword');
                Route::post('update-account', 'updateAccount');
                Route::post('update-image', 'updateAvatar');
            });

            Route::apiResource('papers', ArticleController::class)
                ->missing(function () {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'The article with the requested ID does not exist.',
                    ], 404);
                });


            Route::prefix('author')->group(function () {
                Route::get('analytics', [DashboardController::class, 'index']);

                Route::prefix('papers')->controller(ArticlesController::class)->group(function () {

                    Route::prefix('drafts')->group(function () {
                        Route::get('/', [ArticlesController::class, 'getDrafts']);
                        Route::post('/', [ArticlesController::class, 'createDraft']);
                        Route::post('/{draft}', [ArticlesController::class, 'saveDraftStage']);

                        // Route::post('/{draft}')

                    });

                    Route::prefix('files')->group(function(){
                        Route::post('/',[FileAssetsController::class,'store']);
                        Route::post('/{asset}',[FileAssetsController::class,'update']);
                        Route::delete('/{file}',[FileAssetsController::class,'destroy']);
                    });


                    Route::get('/', 'index');
                    Route::post('/', 'store');
                    Route::put('/{paper}', 'update');
                    Route::get('/{paper}/comments', 'getComments');
                    Route::post('/{paper}/comments', 'createComment');
                });
            });



            Route::prefix('reviewer')->middleware('reviewer')->group(function () {
                Route::get('analytics', [ReviewerArticlesController::class, 'reviewerAnalytics']);

                Route::prefix('papers')->controller(ReviewerArticlesController::class)->group(function () {
                    Route::get('/', 'index');
                    Route::post('/{paper}/change-status', 'changePaperStatus');
                    Route::post('/{paper}/comments', 'createReviewerComment');
                    Route::get('/{paper}/comments', 'getComments');
                });
            });

            Route::prefix('admin')->middleware('admin')->group(function () {
                // Route
                Route::prefix('papers')->controller(AdminArticlesController::class)->group(function () {
                    Route::get('/', 'index');
                    Route::post('/{paper}/assign-reviewer', 'assignPaper');
                    Route::post('/{paper}/reassign-reviewer', 'reAssignPaper');
                    Route::post('/{paper}/change-status', 'changePaperStatus');
                });

                

                Route::get('/users', [UserController::class, 'index']);
                Route::post('/users/invite', [UserController::class, 'inviteUser']);
                Route::post('/users/update-role', [UserController::class, 'updateUserRole']);
                Route::get('/reviewers', [UserController::class, 'getReviewers']);
                Route::delete('/users/{user}', [UserController::class, 'destroy']);
                Route::get('/stats', [AdminStatsController::class, 'adminStats']);
            });
        });
    });

    Route::prefix('papers')->group(function () {

        Route::get('/', [ArticleController::class, 'index']);
        Route::get('/{paper}', [ArticleController::class, 'show']);
        Route::get('/{paper}/download', [ArticleController::class, 'download']);
        Route::get('/search', [ArticleController::class, 'search'])->name('paper.search');

    });



    Route::prefix('sections')->group(function () {
        Route::get('/', [SectionsController::class, 'index']);

    });

    Route::group(['middleware' => 'guest'], function () {
        Route::post('/register', [APIAuthentication::class, 'register'])->name('register.api');
        Route::post('/google/register', [APIAuthentication::class, 'registerWithGoogle']);
        Route::post('/login', [APIAuthentication::class, 'login'])->name('login.api');
        Route::post('/google/login', [APIAuthentication::class, 'loginWithGoogle']);
        Route::get('/roles', [RoleController::class, 'getRoles']);

        Route::get('/countries', [UtilityController::class, 'getCountries']);
    });
});
