<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jorie Invitation</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5; /* Light gray background */
        }

        .container {
            width: 600px;
            height: 80vh;
            margin: 50px auto;
            background-color: #fff; /* White background for the content */
            /* border: 1px solid #bbb; Light gray border */
            border-radius: 5px;
            padding: 30px;
        }

        .header {
            background-color: #45171d; /* Blue header background */
            color: #fff;
            padding: 20px;
            border-radius: 5px 5px 0 0;
        }

        .header h1 {
            text-align: center;
            margin: 0;
        }

        .content {
            padding: 20px;
        }

        .content p {
            margin-bottom: 15px;
            line-height: 1.5; /* Adjust line spacing for readability */
        }

        .info {
            background-color: #f3f3f3; /* Light gray info box */
            padding: 10px;
            border-radius: 3px;
        }

        .info table {
            width: 100%;
            border-collapse: collapse;
        }

        .info th, .info td {
            padding: 5px;
            border: 1px solid #ddd;
        }

        .info th {
            text-align: left;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>User Invitation</h1>
        </div>

        <div class="content">
        <p>You have been invited to UniUyo JORIE application by {{ $admin->first_name .' '. $admin->last_name}}.</p>

            <div class="info">
                <table>
                    <tr>
                        <th>email:</th>
                        <td>{{ $user->email }}</td>
                    </tr>
                    <tr>
                        <th>password:</th>
                        <td>{{ $password }}</td>
                    </tr>
                    <tr>
                        <th>Time:</th>
                        <td>{{ date('Y-m-d g:i:s a') }}</td>
                    </tr>
                </table>
            </div>

            <p style="color: red;">Please ensure to reset your password on the settings menu after you login.</p>

            <p>Sincerely,</p>
            <p>The Uniuyo Journal Team</p>
        </div>
    </div>
</body>
</html>
